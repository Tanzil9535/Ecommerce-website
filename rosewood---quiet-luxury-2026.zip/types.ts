
export type Category = 'Fragrance' | 'Skincare' | 'Accessories' | 'Home' | 'Living';

export interface Product {
  id: string;
  name: string;
  description: string;
  price: number;
  category: Category;
  images: string[];
  stock: number;
  rating: number;
  reviewsCount: number;
  isFeatured?: boolean;
}

export interface User {
  id: string;
  name: string;
  email: string;
  role: 'user' | 'admin';
  avatar?: string;
}

export interface CartItem extends Product {
  quantity: number;
}

export interface Order {
  id: string;
  userId: string;
  items: CartItem[];
  total: number;
  status: 'pending' | 'shipped' | 'delivered';
  createdAt: string;
  address: {
    city: string;
    country: string;
    street: string;
  };
}

export type Page = 'home' | 'shop' | 'product' | 'cart' | 'checkout' | 'auth' | 'admin' | 'profile' | 'wishlist';

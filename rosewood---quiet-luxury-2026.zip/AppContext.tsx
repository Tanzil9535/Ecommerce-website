
import React, { createContext, useContext, useState, useEffect } from 'react';
import { Product, User, CartItem, Order, Page } from './types';
import { INITIAL_PRODUCTS } from './constants';

interface AppContextType {
  products: Product[];
  setProducts: React.Dispatch<React.SetStateAction<Product[]>>;
  cart: CartItem[];
  wishlist: string[];
  addToCart: (product: Product) => void;
  removeFromCart: (id: string) => void;
  updateCartQuantity: (id: string, delta: number) => void;
  toggleWishlist: (id: string) => void;
  clearCart: () => void;
  user: User | null;
  login: (email: string, role?: 'user' | 'admin') => void;
  logout: () => void;
  currentPage: Page;
  setCurrentPage: (page: Page) => void;
  selectedProductId: string | null;
  setSelectedProductId: (id: string | null) => void;
  orders: Order[];
  placeOrder: (order: Omit<Order, 'id' | 'createdAt'>) => void;
  notifications: string[];
  addNotification: (msg: string) => void;
}

const AppContext = createContext<AppContextType | undefined>(undefined);

export const AppProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [products, setProducts] = useState<Product[]>(INITIAL_PRODUCTS);
  const [cart, setCart] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [user, setUser] = useState<User | null>(null);
  const [currentPage, setCurrentPage] = useState<Page>('home');
  const [selectedProductId, setSelectedProductId] = useState<string | null>(null);
  const [orders, setOrders] = useState<Order[]>([]);
  const [notifications, setNotifications] = useState<string[]>([]);

  useEffect(() => {
    const savedCart = localStorage.getItem('rosewood_cart');
    if (savedCart) setCart(JSON.parse(savedCart));
    const savedUser = localStorage.getItem('rosewood_user');
    if (savedUser) setUser(JSON.parse(savedUser));
    const savedWish = localStorage.getItem('rosewood_wishlist');
    if (savedWish) setWishlist(JSON.parse(savedWish));
  }, []);

  useEffect(() => {
    localStorage.setItem('rosewood_cart', JSON.stringify(cart));
  }, [cart]);

  useEffect(() => {
    localStorage.setItem('rosewood_wishlist', JSON.stringify(wishlist));
  }, [wishlist]);

  const addNotification = (msg: string) => {
    const id = Math.random().toString();
    setNotifications(prev => [...prev, msg]);
    setTimeout(() => {
      setNotifications(prev => prev.filter(n => n !== msg));
    }, 3000);
  };

  const addToCart = (product: Product) => {
    setCart(prev => {
      const existing = prev.find(item => item.id === product.id);
      if (existing) {
        return prev.map(item => item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      }
      return [...prev, { ...product, quantity: 1 }];
    });
    addNotification(`${product.name} added to bag`);
  };

  const toggleWishlist = (id: string) => {
    setWishlist(prev => {
      const isExist = prev.includes(id);
      if (isExist) {
        addNotification(`Removed from wishlist`);
        return prev.filter(item => item !== id);
      }
      addNotification(`Added to wishlist`);
      return [...prev, id];
    });
  };

  const removeFromCart = (id: string) => {
    setCart(prev => prev.filter(item => item.id !== id));
  };

  const updateCartQuantity = (id: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.id === id) {
        const newQty = Math.max(1, item.quantity + delta);
        return { ...item, quantity: newQty };
      }
      return item;
    }));
  };

  const clearCart = () => setCart([]);

  const login = (email: string, role: 'user' | 'admin' = 'user') => {
    const newUser: User = {
      id: Math.random().toString(36).substr(2, 9),
      name: email.split('@')[0],
      email,
      role,
      avatar: `https://i.pravatar.cc/150?u=${email}`
    };
    setUser(newUser);
    localStorage.setItem('rosewood_user', JSON.stringify(newUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('rosewood_user');
    setCurrentPage('home');
  };

  const placeOrder = (orderData: Omit<Order, 'id' | 'createdAt'>) => {
    const newOrder: Order = {
      ...orderData,
      id: `ORD-${Math.random().toString(36).toUpperCase().substr(2, 6)}`,
      createdAt: new Date().toISOString(),
    };
    setOrders(prev => [newOrder, ...prev]);
    clearCart();
    setCurrentPage('profile');
    addNotification('Order placed successfully');
  };

  return (
    <AppContext.Provider value={{
      products, setProducts,
      cart, wishlist, addToCart, removeFromCart, updateCartQuantity, toggleWishlist, clearCart,
      user, login, logout,
      currentPage, setCurrentPage,
      selectedProductId, setSelectedProductId,
      orders, placeOrder,
      notifications, addNotification
    }}>
      {children}
    </AppContext.Provider>
  );
};

export const useAppContext = () => {
  const context = useContext(AppContext);
  if (!context) throw new Error('useAppContext must be used within AppProvider');
  return context;
};


import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { ShoppingBag, User, Search, LogOut, LayoutDashboard, Heart, Menu, X } from 'lucide-react';
import { useAppContext } from '../AppContext';

export const Navbar: React.FC = () => {
  const { cart, wishlist, user, setCurrentPage, currentPage, logout } = useAppContext();
  const [isMenuOpen, setIsMenuOpen] = React.useState(false);

  const cartCount = cart.reduce((acc, item) => acc + item.quantity, 0);

  return (
    <nav className="fixed top-0 left-0 w-full z-50 glass">
      <div className="max-w-[95rem] mx-auto px-6">
        <div className="flex justify-between items-center h-24">
          <div className="flex items-center gap-16">
            <button onClick={() => setCurrentPage('home')} className="text-3xl font-serif font-black tracking-tighter text-stone-900">
              ROSEWOOD<span className="text-latte-400">.</span>
            </button>
            <div className="hidden lg:flex space-x-12">
              {['Home', 'Shop'].map((item) => (
                <button
                  key={item}
                  onClick={() => setCurrentPage(item.toLowerCase() as any)}
                  className={`text-[11px] font-bold uppercase tracking-[0.3em] transition-all relative group ${
                    currentPage === item.toLowerCase() ? 'text-stone-900' : 'text-latte-500 hover:text-stone-900'
                  }`}
                >
                  {item}
                  <span className={`absolute -bottom-2 left-0 w-0 h-[1px] bg-stone-900 transition-all duration-300 group-hover:w-full ${currentPage === item.toLowerCase() ? 'w-full' : ''}`} />
                </button>
              ))}
            </div>
          </div>

          <div className="flex items-center gap-8">
            <button className="text-latte-800 hover:text-stone-900 transition-colors">
              <Search size={20} strokeWidth={1.5} />
            </button>

            <button 
               onClick={() => setCurrentPage('wishlist')}
               className="text-latte-800 hover:text-stone-900 transition-colors relative"
            >
              <Heart size={20} strokeWidth={1.5} />
              {wishlist.length > 0 && (
                 <span className="absolute -top-1 -right-1 w-2 h-2 bg-red-400 rounded-full" />
              )}
            </button>
            
            <button 
              onClick={() => setCurrentPage('cart')}
              className="text-latte-800 hover:text-stone-900 transition-colors relative"
            >
              <ShoppingBag size={20} strokeWidth={1.5} />
              {cartCount > 0 && (
                <span className="absolute -top-2 -right-2 bg-stone-900 text-white text-[9px] font-bold h-4 w-4 rounded-full flex items-center justify-center">
                  {cartCount}
                </span>
              )}
            </button>

            <div className="h-6 w-[1px] bg-latte-200 hidden md:block"></div>

            {user ? (
              <div className="flex items-center gap-6">
                <button 
                  onClick={() => setCurrentPage(user.role === 'admin' ? 'admin' : 'profile')}
                  className="hidden md:flex items-center gap-3 text-stone-900 hover:text-latte-600 transition-colors"
                >
                  <div className="w-8 h-8 rounded-full overflow-hidden border border-latte-200">
                    <img src={user.avatar} className="w-full h-full object-cover" alt="" />
                  </div>
                  <span className="text-xs font-bold uppercase tracking-widest">{user.name}</span>
                </button>
                <button onClick={logout} className="text-latte-400 hover:text-red-500 transition-all">
                  <LogOut size={18} />
                </button>
              </div>
            ) : (
              <button 
                onClick={() => setCurrentPage('auth')}
                className="bg-stone-900 text-white px-8 py-3 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-latte-900 transition-all shadow-xl shadow-latte-200"
              >
                Sign In
              </button>
            )}
            
            <button 
              className="lg:hidden text-stone-900"
              onClick={() => setIsMenuOpen(!isMenuOpen)}
            >
              {isMenuOpen ? <X size={24} /> : <Menu size={24} />}
            </button>
          </div>
        </div>
      </div>
      
      <AnimatePresence>
        {isMenuOpen && (
          <motion.div
            initial={{ opacity: 0, scale: 0.95 }}
            animate={{ opacity: 1, scale: 1 }}
            exit={{ opacity: 0, scale: 0.95 }}
            className="lg:hidden glass border-t border-latte-100 overflow-hidden"
          >
            <div className="px-6 py-12 space-y-8 text-center">
              <button onClick={() => { setCurrentPage('home'); setIsMenuOpen(false); }} className="block w-full text-2xl font-serif italic">Home</button>
              <button onClick={() => { setCurrentPage('shop'); setIsMenuOpen(false); }} className="block w-full text-2xl font-serif italic">Shop Collection</button>
              {user && (
                 <button onClick={() => { setCurrentPage(user.role === 'admin' ? 'admin' : 'profile'); setIsMenuOpen(false); }} className="block w-full text-2xl font-serif italic">
                   My Sanctuary
                 </button>
              )}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </nav>
  );
};

export const Footer: React.FC = () => {
  return (
    <footer className="bg-latte-50 text-latte-900 py-32 px-6 border-t border-latte-200">
      <div className="max-w-[95rem] mx-auto grid grid-cols-1 md:grid-cols-12 gap-16">
        <div className="md:col-span-4">
          <h3 className="text-4xl font-serif font-black tracking-tighter mb-4">ROSEWOOD<span className="text-latte-400">.</span></h3>
          <p className="text-sm font-bold uppercase tracking-[0.3em] text-latte-400 mb-8">Created by FEHMIDA & SAHIRA</p>
          <p className="text-lg font-light leading-relaxed max-w-sm opacity-70">
            A 2026 legacy brand focusing on the architecture of everyday life. Sourced ethically, designed eternally.
          </p>
          <div className="mt-12 flex gap-6">
            {['IG', 'TW', 'LI'].map(social => (
              <button key={social} className="text-xs font-bold uppercase tracking-widest hover:text-latte-400 transition-colors">{social}</button>
            ))}
          </div>
        </div>
        <div className="md:col-span-2">
          <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] mb-8 text-latte-400">Navigation</h4>
          <ul className="space-y-4 text-sm font-medium">
            <li><button className="hover:opacity-50 transition-all">Seasonal Drops</button></li>
            <li><button className="hover:opacity-50 transition-all">Heritage Line</button></li>
            <li><button className="hover:opacity-50 transition-all">Home Geometry</button></li>
            <li><button className="hover:opacity-50 transition-all">2026 Lookbook</button></li>
          </ul>
        </div>
        <div className="md:col-span-2">
          <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] mb-8 text-latte-400">Assistance</h4>
          <ul className="space-y-4 text-sm font-medium">
            <li><button className="hover:opacity-50 transition-all">Private Client</button></li>
            <li><button className="hover:opacity-50 transition-all">Bespoke Gifting</button></li>
            <li><button className="hover:opacity-50 transition-all">Global Concierge</button></li>
            <li><button className="hover:opacity-50 transition-all">Sustainability Report</button></li>
          </ul>
        </div>
        <div className="md:col-span-4 bg-latte-100 p-10 rounded-[3rem]">
          <h4 className="text-2xl font-serif italic mb-6">"Quiet luxury is the sound of one's own character."</h4>
          <p className="text-xs font-bold uppercase tracking-widest text-latte-400">— Rosewood Philosophy 2026</p>
        </div>
      </div>
      <div className="max-w-[95rem] mx-auto mt-32 pt-12 border-t border-latte-200 flex flex-col md:flex-row justify-between items-center text-[10px] font-bold uppercase tracking-widest text-latte-400 gap-8">
        <div>&copy; 2026 Rosewood. Architectural Life Objects.</div>
        <div className="flex gap-12">
          <button className="hover:text-stone-900 transition-colors">Privacy Privacy</button>
          <button className="hover:text-stone-900 transition-colors">Terms of Exchange</button>
        </div>
      </div>
    </footer>
  );
};

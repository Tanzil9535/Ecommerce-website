
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Star, Eye, ShoppingCart, Heart, Loader2 } from 'lucide-react';
import { Product } from '../types';
import { useAppContext } from '../AppContext';

export const ProductCard: React.FC<{ product: Product }> = ({ product }) => {
  const { addToCart, setCurrentPage, setSelectedProductId, toggleWishlist, wishlist } = useAppContext();
  const [isImgLoaded, setIsImgLoaded] = useState(false);
  const isWishlisted = wishlist.includes(product.id);

  const handleQuickView = (e: React.MouseEvent) => {
    e.stopPropagation();
    setSelectedProductId(product.id);
    setCurrentPage('product');
  };

  return (
    <motion.div 
      initial={{ opacity: 0, y: 30 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true }}
      className="group"
    >
      <div className="relative aspect-[3/4] overflow-hidden rounded-[2rem] bg-latte-50 shadow-sm transition-all duration-700 hover:shadow-2xl hover:shadow-latte-200/40">
        {!isImgLoaded && (
          <div className="absolute inset-0 flex items-center justify-center bg-latte-100 animate-pulse">
            <Loader2 className="text-latte-400 animate-spin" size={24} />
          </div>
        )}
        <img 
          src={product.images[0]} 
          alt={product.name}
          onLoad={() => setIsImgLoaded(true)}
          className={`h-full w-full object-cover transition-all duration-[1.5s] ${isImgLoaded ? 'opacity-100 scale-100' : 'opacity-0 scale-105'} group-hover:scale-105`}
        />
        
        {/* Wishlist Button */}
        <button 
          onClick={(e) => { e.stopPropagation(); toggleWishlist(product.id); }}
          className={`absolute top-6 right-6 p-3 rounded-full glass transition-all z-10 ${isWishlisted ? 'text-red-400' : 'text-latte-800 hover:bg-white'}`}
        >
          <Heart size={18} fill={isWishlisted ? "currentColor" : "none"} />
        </button>

        {/* Action Overlay */}
        <div className="absolute inset-x-0 bottom-0 p-6 translate-y-full group-hover:translate-y-0 transition-transform duration-500 bg-gradient-to-t from-black/20 to-transparent">
          <button 
            onClick={(e) => { e.stopPropagation(); addToCart(product); }}
            className="w-full bg-latte-900 text-white py-4 rounded-2xl flex items-center justify-center gap-3 font-medium tracking-tight shadow-xl hover:bg-stone-950 active:scale-95 transition-all"
          >
            <ShoppingCart size={18} /> Add to Bag
          </button>
        </div>

        {product.isFeatured && (
          <span className="absolute top-6 left-6 glass text-[10px] font-bold uppercase tracking-[0.2em] py-2 px-4 rounded-full text-latte-800">
            Heritage
          </span>
        )}
      </div>

      <div className="mt-6 flex justify-between items-start px-2">
        <div className="flex-1">
          <p className="text-[10px] text-latte-500 uppercase tracking-[0.2em] font-semibold mb-1">{product.category}</p>
          <h3 
            onClick={handleQuickView}
            className="text-lg font-serif font-medium text-stone-800 cursor-pointer hover:text-latte-600 transition-colors line-clamp-1"
          >
            {product.name}
          </h3>
          <div className="flex items-center gap-2 mt-2">
            <div className="flex text-gold-400">
              <Star size={12} fill="currentColor" />
            </div>
            <span className="text-[10px] text-latte-400 font-bold tracking-tighter">{product.rating} · {product.reviewsCount} reviews</span>
          </div>
        </div>
        <p className="text-xl font-light text-stone-900 ml-4">${product.price}</p>
      </div>
    </motion.div>
  );
};

export const SectionHeading: React.FC<{ title: string; subtitle?: string; centered?: boolean }> = ({ title, subtitle, centered }) => (
  <div className={`mb-16 ${centered ? 'text-center' : ''}`}>
    {subtitle && (
      <motion.p 
        initial={{ opacity: 0 }}
        whileInView={{ opacity: 1 }}
        className="text-latte-600 text-[10px] font-bold uppercase tracking-[0.4em] mb-4"
      >
        {subtitle}
      </motion.p>
    )}
    <motion.h2 
      initial={{ opacity: 0, y: 15 }}
      whileInView={{ opacity: 1, y: 0 }}
      className="text-4xl md:text-6xl font-serif text-stone-900 tracking-tight leading-none"
    >
      {title}
    </motion.h2>
  </div>
);

export const Toast: React.FC = () => {
  const { notifications } = useAppContext();
  return (
    <div className="fixed bottom-10 right-10 z-[100] flex flex-col gap-3 pointer-events-none">
      <AnimatePresence>
        {notifications.map((note, i) => (
          <motion.div
            key={note + i}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, scale: 0.9 }}
            className="bg-stone-900 text-white px-8 py-4 rounded-full text-sm font-medium shadow-2xl flex items-center gap-3 backdrop-blur-xl bg-opacity-90"
          >
            <ShoppingCart size={16} className="text-latte-400" />
            {note}
          </motion.div>
        ))}
      </AnimatePresence>
    </div>
  );
};

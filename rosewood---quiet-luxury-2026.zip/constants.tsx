
import { Product } from './types';

export const INITIAL_PRODUCTS: Product[] = [
  {
    id: '1',
    name: 'Santal & Cedar 04',
    description: 'A modern olfactory masterpiece balancing raw cedarwood with creamy Australian sandalwood and a hint of white iris. The essence of a 2026 morning.',
    price: 155,
    category: 'Fragrance',
    images: ['https://images.unsplash.com/photo-1594035910387-fea47794261f?auto=format&fit=crop&q=80&w=800'],
    stock: 12,
    rating: 4.9,
    reviewsCount: 312,
    isFeatured: true
  },
  {
    id: '2',
    name: 'Liquid Gold Serum',
    description: 'A revolutionary formula using micro-encapsulated retinal and golden saffron extracts. Delivers deep cellular hydration and architectural glow.',
    price: 98,
    category: 'Skincare',
    images: ['https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&q=80&w=800'],
    stock: 45,
    rating: 4.8,
    reviewsCount: 142,
    isFeatured: true
  },
  {
    id: '3',
    name: 'Architectural Vase',
    description: 'Hand-sculpted matte ceramic with an organic silhouette. Part of our signature Home Geometry series, designed for permanent display.',
    price: 210,
    category: 'Home',
    images: ['https://images.unsplash.com/photo-1581783898377-1c85bf937427?auto=format&fit=crop&q=80&w=800'],
    stock: 5,
    rating: 5.0,
    reviewsCount: 28,
    isFeatured: true
  },
  {
    id: '4',
    name: 'Ethereal Silk Robe',
    description: '100% grade 6A mulberry silk in a muted sand hue. Features laser-cut edges and a seamless drape for ultimate home luxury.',
    price: 320,
    category: 'Accessories',
    images: ['https://images.unsplash.com/photo-1621259182978-f09e5e2ca1ff?auto=format&fit=crop&q=80&w=800'],
    stock: 8,
    rating: 4.7,
    reviewsCount: 64,
    isFeatured: false
  },
  {
    id: '5',
    name: 'Ivory Bouclé Chair',
    description: 'Sculptural seating designed for the minimalist home. Upholstered in premium Italian bouclé wool with a soft-touch finish.',
    price: 1850,
    category: 'Living',
    images: ['https://images.unsplash.com/photo-1567538096630-e0c55bd6374c?auto=format&fit=crop&q=80&w=800'],
    stock: 3,
    rating: 4.9,
    reviewsCount: 15,
    isFeatured: true
  },
  {
    id: '6',
    name: 'Nude Palette Diffuser',
    description: 'Ultrasonic technology paired with a minimalist stone cover. Uses cold-mist diffusion to preserve essential oil integrity.',
    price: 125,
    category: 'Home',
    images: ['https://images.unsplash.com/photo-1614352132332-960251147071?auto=format&fit=crop&q=80&w=800'],
    stock: 20,
    rating: 4.6,
    reviewsCount: 89,
    isFeatured: false
  },
  {
    id: '7',
    name: 'Obsidian Facial Sculptor',
    description: 'Hand-carved volcanic obsidian tool designed to improve lymphatic drainage and define facial architecture through Gua Sha.',
    price: 65,
    category: 'Skincare',
    images: ['https://images.unsplash.com/photo-1619451334792-150fd785ee74?auto=format&fit=crop&q=80&w=800'],
    stock: 30,
    rating: 4.9,
    reviewsCount: 215,
    isFeatured: true
  },
  {
    id: '8',
    name: 'Latte Leather Tote',
    description: 'Butter-soft Italian calfskin leather in our signature latte hue. Features an integrated magnetic closure and internal organization.',
    price: 680,
    category: 'Accessories',
    images: ['https://images.unsplash.com/photo-1584917865442-de89df76afd3?auto=format&fit=crop&q=80&w=800'],
    stock: 6,
    rating: 4.8,
    reviewsCount: 42,
    isFeatured: true
  },
  {
    id: '9',
    name: 'Smoke Glass Carafe',
    description: 'Hand-blown mouth-blown glass with a subtle gradient smoke finish. An elegant centerpiece for contemporary hydration.',
    price: 140,
    category: 'Home',
    images: ['https://images.unsplash.com/photo-1621259182978-f09e5e2ca1ff?auto=format&fit=crop&q=80&w=800'],
    stock: 15,
    rating: 4.7,
    reviewsCount: 56,
    isFeatured: false
  },
  {
    id: '10',
    name: 'Raw Linen Bedding',
    description: 'Stonewashed European flax linen set. Naturally temperature regulating and designed to soften with every wash.',
    price: 450,
    category: 'Living',
    images: ['https://images.unsplash.com/photo-1522771739844-6a9f6d5f14af?auto=format&fit=crop&q=80&w=800'],
    stock: 10,
    rating: 5.0,
    reviewsCount: 108,
    isFeatured: true
  },
  {
    id: '11',
    name: 'Concrete Aura Candle',
    description: 'Brutalist concrete vessel containing a soy wax blend of pink pepper and white musk. A slow-burn sensory experience.',
    price: 85,
    category: 'Home',
    images: ['https://images.unsplash.com/photo-1603006905003-be475563bc59?auto=format&fit=crop&q=80&w=800'],
    stock: 40,
    rating: 4.8,
    reviewsCount: 192,
    isFeatured: false
  },
  {
    id: '12',
    name: 'Titanium Frame Eye-wear',
    description: 'Ultra-light aerospace-grade titanium frames with minimalist engineering. Zero-distortion lenses for clear vision.',
    price: 520,
    category: 'Accessories',
    images: ['https://images.unsplash.com/photo-1572635196237-14b3f281503f?auto=format&fit=crop&q=80&w=800'],
    stock: 12,
    rating: 4.9,
    reviewsCount: 74,
    isFeatured: true
  }
];

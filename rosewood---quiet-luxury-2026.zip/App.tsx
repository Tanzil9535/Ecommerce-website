
import React from 'react';
import { AppProvider, useAppContext } from './AppContext';
import { Navbar, Footer } from './components/Layout';
import { Home } from './pages/Home';
import { Shop } from './pages/Shop';
import { ProductDetail } from './pages/ProductDetail';
import { Cart } from './pages/Cart';
import { Auth } from './pages/Auth';
import { AdminDashboard } from './pages/AdminDashboard';
import { Checkout } from './pages/Checkout';
import { motion, AnimatePresence } from 'framer-motion';
import { Toast, ProductCard } from './components/UI';

const Router: React.FC = () => {
  const { currentPage, wishlist, products, orders } = useAppContext();

  const renderPage = () => {
    switch (currentPage) {
      case 'home': return <Home />;
      case 'shop': return <Shop />;
      case 'product': return <ProductDetail />;
      case 'cart': return <Cart />;
      case 'auth': return <Auth />;
      case 'admin': return <AdminDashboard />;
      case 'checkout': return <Checkout />;
      case 'wishlist': return (
        <div className="pt-40 pb-32 max-w-7xl mx-auto px-4 min-h-[70vh]">
          <h1 className="text-5xl font-serif text-stone-900 mb-12">Your Wishlist</h1>
          {wishlist.length === 0 ? (
            <p className="text-latte-500 text-xl font-light">Your sanctuary of items is currently empty.</p>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-12">
              {products.filter(p => wishlist.includes(p.id)).map(product => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          )}
        </div>
      );
      case 'profile': return (
        <div className="pt-48 pb-32 max-w-5xl mx-auto px-6">
          <h1 className="text-5xl font-serif text-stone-900 mb-12">Account Sanctuary</h1>
          <div className="space-y-12">
            <section>
              <h2 className="text-xl font-bold uppercase tracking-[0.3em] text-latte-400 mb-8">Acquisition History</h2>
              {orders.length === 0 ? (
                <p className="text-latte-500 font-light text-lg">Your legacy of purchases will be recorded here.</p>
              ) : (
                <div className="space-y-6">
                  {orders.map(order => (
                    <div key={order.id} className="bg-white p-8 rounded-[2rem] border border-latte-100 shadow-sm flex flex-col md:flex-row justify-between gap-8">
                      <div>
                        <p className="text-[10px] font-bold uppercase tracking-widest text-latte-400 mb-2">Order ID: {order.id}</p>
                        <p className="text-xs text-stone-500 mb-4">{new Date(order.createdAt).toLocaleDateString()}</p>
                        <div className="flex gap-2">
                          {order.items.map(item => (
                            <div key={item.id} className="w-12 h-16 rounded-lg overflow-hidden bg-latte-100 border border-latte-50">
                              <img src={item.images[0]} className="w-full h-full object-cover" />
                            </div>
                          ))}
                        </div>
                      </div>
                      <div className="text-right flex flex-col justify-center">
                        <p className="text-2xl font-light text-stone-900 mb-1">${order.total}</p>
                        <span className="inline-block px-4 py-1 rounded-full bg-latte-50 text-latte-600 text-[10px] font-bold uppercase tracking-widest">
                          {order.status}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </section>
          </div>
        </div>
      );
      default: return <Home />;
    }
  };

  return (
    <div className="flex flex-col min-h-screen">
      {currentPage !== 'auth' && <Navbar />}
      <Toast />
      <main className="flex-grow">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentPage}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            transition={{ duration: 0.5, ease: [0.22, 1, 0.36, 1] }}
          >
            {renderPage()}
          </motion.div>
        </AnimatePresence>
      </main>
      {currentPage !== 'auth' && <Footer />}
    </div>
  );
};

const App: React.FC = () => {
  return (
    <AppProvider>
      <Router />
    </AppProvider>
  );
};

export default App;


import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Lock, User, ArrowRight } from 'lucide-react';
import { useAppContext } from '../AppContext';

export const Auth: React.FC = () => {
  const { login, setCurrentPage } = useAppContext();
  const [isLogin, setIsLogin] = useState(true);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // Simulate real login
    const role = email.includes('admin') ? 'admin' : 'user';
    login(email, role);
    setCurrentPage('home');
  };

  return (
    <div className="min-h-screen pt-20 flex items-center justify-center bg-beige-50 px-4">
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="w-full max-w-5xl grid grid-cols-1 lg:grid-cols-2 rounded-[3rem] overflow-hidden shadow-2xl bg-white"
      >
        {/* Form Side */}
        <div className="p-12 md:p-16">
          <button 
            onClick={() => setCurrentPage('home')}
            className="text-2xl font-serif font-bold text-stone-900 mb-12 block"
          >
            ROSEWOOD
          </button>
          
          <h2 className="text-4xl font-serif text-stone-800 mb-4">
            {isLogin ? 'Welcome back' : 'Create account'}
          </h2>
          <p className="text-stone-500 font-light mb-10">
            {isLogin 
              ? 'Sign in to access your luxury preferences and saved items.' 
              : 'Join our exclusive circle for a curated shopping experience.'
            }
          </p>

          <form onSubmit={handleSubmit} className="space-y-6">
            {!isLogin && (
              <div className="relative">
                <User className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
                <input 
                  type="text" 
                  placeholder="Full name"
                  className="w-full bg-stone-50 border border-stone-100 rounded-2xl pl-12 pr-6 py-4 text-sm focus:outline-none focus:border-latte-300 transition-all"
                />
              </div>
            )}
            <div className="relative">
              <Mail className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
              <input 
                type="email" 
                placeholder="Email address"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="w-full bg-stone-50 border border-stone-100 rounded-2xl pl-12 pr-6 py-4 text-sm focus:outline-none focus:border-latte-300 transition-all"
              />
            </div>
            <div className="relative">
              <Lock className="absolute left-4 top-1/2 -translate-y-1/2 text-stone-400" size={18} />
              <input 
                type="password" 
                placeholder="Password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full bg-stone-50 border border-stone-100 rounded-2xl pl-12 pr-6 py-4 text-sm focus:outline-none focus:border-latte-300 transition-all"
              />
            </div>
            
            {isLogin && (
              <div className="text-right">
                <button type="button" className="text-xs text-latte-600 font-semibold hover:text-latte-800">Forgot password?</button>
              </div>
            )}

            <button 
              type="submit"
              className="w-full bg-stone-900 text-white py-4 rounded-2xl font-bold flex items-center justify-center gap-3 hover:bg-stone-800 transition-all shadow-xl shadow-latte-100"
            >
              {isLogin ? 'Sign In' : 'Create Account'}
              <ArrowRight size={20} />
            </button>
          </form>

          <div className="mt-12 pt-8 border-t border-stone-100 text-center">
            <p className="text-sm text-stone-500">
              {isLogin ? "Don't have an account?" : "Already have an account?"} {' '}
              <button 
                onClick={() => setIsLogin(!isLogin)}
                className="text-stone-900 font-bold hover:text-latte-800 transition-colors"
              >
                {isLogin ? 'Register now' : 'Login here'}
              </button>
            </p>
          </div>
        </div>

        {/* Visual Side */}
        <div className="hidden lg:block relative overflow-hidden">
          <img 
            src="https://images.unsplash.com/photo-1596462502278-27bfad450516?auto=format&fit=crop&q=80&w=800" 
            alt="Auth context"
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-stone-900/60 to-transparent flex items-end p-16">
            <div className="text-white">
              <h3 className="text-3xl font-serif italic mb-4">"The details are not the details. They make the design."</h3>
              <p className="text-latte-100/70 font-light">Charles Eames</p>
            </div>
          </div>
        </div>
      </motion.div>
    </div>
  );
};

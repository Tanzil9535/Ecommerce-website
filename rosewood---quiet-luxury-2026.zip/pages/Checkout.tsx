
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { ChevronLeft, CreditCard, Truck, ShieldCheck, ArrowRight } from 'lucide-react';
import { useAppContext } from '../AppContext';

export const Checkout: React.FC = () => {
  const { cart, placeOrder, setCurrentPage, user } = useAppContext();
  const [step, setStep] = useState(1);
  const [formData, setFormData] = useState({
    name: user?.name || '',
    email: user?.email || '',
    street: '',
    city: '',
    country: '',
    card: '',
    expiry: '',
    cvv: ''
  });

  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const shipping = subtotal > 150 ? 0 : 25;
  const total = subtotal + shipping;

  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setFormData({ ...formData, [e.target.name]: e.target.value });
  };

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    if (!user) {
      setCurrentPage('auth');
      return;
    }
    placeOrder({
      userId: user.id,
      items: cart,
      total: total,
      status: 'pending',
      address: {
        street: formData.street,
        city: formData.city,
        country: formData.country
      }
    });
  };

  if (cart.length === 0) {
    return (
      <div className="pt-48 pb-32 text-center">
        <h2 className="text-3xl font-serif mb-4 text-stone-900">Your bag is empty</h2>
        <button 
          onClick={() => setCurrentPage('shop')}
          className="bg-stone-900 text-white px-10 py-4 rounded-full font-bold uppercase tracking-widest text-xs"
        >
          Explore Collection
        </button>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-24 max-w-7xl mx-auto px-6">
      <button 
        onClick={() => setCurrentPage('cart')}
        className="flex items-center gap-2 text-latte-400 hover:text-stone-900 mb-12"
      >
        <ChevronLeft size={20} />
        <span className="text-xs font-bold uppercase tracking-widest">Return to Bag</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-16">
        {/* Form Section */}
        <div className="lg:col-span-7">
          <h1 className="text-5xl font-serif text-stone-900 mb-12">Secure Exchange</h1>
          
          <form onSubmit={handlePlaceOrder} className="space-y-12">
            {/* Step 1: Shipping */}
            <section className="space-y-6">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-10 h-10 rounded-full bg-latte-900 text-white flex items-center justify-center font-bold">1</div>
                <h3 className="text-xl font-serif">Shipping Sanctuary</h3>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-latte-500">Full Name</label>
                  <input 
                    name="name" value={formData.name} onChange={handleInputChange} required
                    className="w-full bg-latte-50 border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-latte-200"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-latte-500">Email Address</label>
                  <input 
                    name="email" value={formData.email} onChange={handleInputChange} required type="email"
                    className="w-full bg-latte-50 border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-latte-200"
                  />
                </div>
                <div className="md:col-span-2 space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-latte-500">Street Address</label>
                  <input 
                    name="street" value={formData.street} onChange={handleInputChange} required
                    className="w-full bg-latte-50 border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-latte-200"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-latte-500">City</label>
                  <input 
                    name="city" value={formData.city} onChange={handleInputChange} required
                    className="w-full bg-latte-50 border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-latte-200"
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-latte-500">Country</label>
                  <input 
                    name="country" value={formData.country} onChange={handleInputChange} required
                    className="w-full bg-latte-50 border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-latte-200"
                  />
                </div>
              </div>
            </section>

            {/* Step 2: Payment */}
            <section className="space-y-6">
              <div className="flex items-center gap-4 mb-8">
                <div className="w-10 h-10 rounded-full bg-latte-900 text-white flex items-center justify-center font-bold">2</div>
                <h3 className="text-xl font-serif">Financial Authentication</h3>
              </div>
              
              <div className="space-y-6">
                <div className="bg-latte-900 text-white p-8 rounded-[2rem] shadow-2xl space-y-8 relative overflow-hidden">
                  <div className="flex justify-between items-start">
                    <CreditCard size={32} />
                    <div className="w-12 h-8 bg-latte-100/20 rounded-lg"></div>
                  </div>
                  <div className="text-2xl font-mono tracking-widest">
                    {formData.card || '•••• •••• •••• ••••'}
                  </div>
                  <div className="flex justify-between items-end">
                    <div className="space-y-1">
                      <p className="text-[8px] uppercase tracking-widest opacity-60">Architect Name</p>
                      <p className="text-xs uppercase tracking-widest">{formData.name || 'Your Name'}</p>
                    </div>
                    <div className="space-y-1 text-right">
                      <p className="text-[8px] uppercase tracking-widest opacity-60">Expiry</p>
                      <p className="text-xs uppercase tracking-widest">{formData.expiry || 'MM/YY'}</p>
                    </div>
                  </div>
                  <div className="absolute -right-10 -bottom-10 w-40 h-40 bg-white/5 rounded-full blur-3xl"></div>
                </div>

                <div className="space-y-2">
                  <label className="text-[10px] font-bold uppercase tracking-widest text-latte-500">Card Number</label>
                  <input 
                    name="card" maxLength={16} value={formData.card} onChange={handleInputChange} required
                    placeholder="0000 0000 0000 0000"
                    className="w-full bg-latte-50 border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-latte-200"
                  />
                </div>
                <div className="grid grid-cols-2 gap-6">
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-latte-500">Expiry Date</label>
                    <input 
                      name="expiry" maxLength={5} value={formData.expiry} onChange={handleInputChange} required
                      placeholder="MM/YY"
                      className="w-full bg-latte-50 border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-latte-200"
                    />
                  </div>
                  <div className="space-y-2">
                    <label className="text-[10px] font-bold uppercase tracking-widest text-latte-500">CVV</label>
                    <input 
                      name="cvv" maxLength={3} value={formData.cvv} onChange={handleInputChange} required
                      placeholder="000"
                      className="w-full bg-latte-50 border-none rounded-2xl p-4 text-sm focus:ring-2 focus:ring-latte-200"
                    />
                  </div>
                </div>
              </div>
            </section>

            <button 
              type="submit"
              className="w-full bg-stone-900 text-white py-6 rounded-full font-bold uppercase tracking-[0.2em] text-xs flex items-center justify-center gap-4 hover:bg-stone-800 shadow-2xl"
            >
              Complete Asset Acquisition
              <ArrowRight size={18} />
            </button>
          </form>
        </div>

        {/* Sidebar Order Summary */}
        <div className="lg:col-span-5">
          <div className="glass p-10 rounded-[3rem] sticky top-32">
            <h3 className="text-2xl font-serif mb-8 text-stone-900">Order Manifest</h3>
            <div className="space-y-6 mb-8 max-h-96 overflow-y-auto pr-2 custom-scrollbar">
              {cart.map(item => (
                <div key={item.id} className="flex gap-4">
                  <div className="w-20 h-24 rounded-2xl overflow-hidden bg-latte-100">
                    <img src={item.images[0]} className="w-full h-full object-cover" />
                  </div>
                  <div className="flex-1">
                    <p className="text-[10px] font-bold uppercase tracking-widest text-latte-400 mb-1">{item.category}</p>
                    <h4 className="font-medium text-stone-800 mb-1">{item.name}</h4>
                    <p className="text-xs text-latte-500">{item.quantity} x ${item.price}</p>
                  </div>
                  <p className="text-sm font-bold">${item.price * item.quantity}</p>
                </div>
              ))}
            </div>

            <div className="space-y-4 pt-8 border-t border-latte-100">
              <div className="flex justify-between text-sm text-latte-500">
                <span>Subtotal</span>
                <span>${subtotal}</span>
              </div>
              <div className="flex justify-between text-sm text-latte-500">
                <span>Sanctuary Delivery</span>
                <span>${shipping}</span>
              </div>
              <div className="flex justify-between text-xl font-bold text-stone-900 pt-4">
                <span>Total Asset Value</span>
                <span>${total}</span>
              </div>
            </div>

            <div className="mt-12 space-y-4">
              <div className="flex items-center gap-3 text-latte-400">
                <ShieldCheck size={18} />
                <span className="text-[10px] uppercase font-bold tracking-widest">Architectural Security Guaranteed</span>
              </div>
              <div className="flex items-center gap-3 text-latte-400">
                <Truck size={18} />
                <span className="text-[10px] uppercase font-bold tracking-widest">Global Concierge Logistics</span>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

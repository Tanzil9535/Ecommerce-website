
import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { SlidersHorizontal, Search, ChevronDown, Sparkles, FilterX } from 'lucide-react';
import { useAppContext } from '../AppContext';
import { ProductCard, SectionHeading } from '../components/UI';
import { Category } from '../types';

export const Shop: React.FC = () => {
  const { products } = useAppContext();
  const [activeCategory, setActiveCategory] = useState<Category | 'All'>('All');
  const [searchQuery, setSearchQuery] = useState('');
  const [sortBy, setSortBy] = useState<'price-low' | 'price-high' | 'rating'>('rating');
  const [priceRange, setPriceRange] = useState<number>(2000);

  const categories: (Category | 'All')[] = ['All', 'Fragrance', 'Skincare', 'Accessories', 'Home', 'Living'];

  const filteredProducts = useMemo(() => {
    let result = products.filter(p => {
      const matchesCategory = activeCategory === 'All' || p.category === activeCategory;
      const matchesSearch = p.name.toLowerCase().includes(searchQuery.toLowerCase()) || 
                          p.description.toLowerCase().includes(searchQuery.toLowerCase());
      const matchesPrice = p.price <= priceRange;
      return matchesCategory && matchesSearch && matchesPrice;
    });

    if (sortBy === 'price-low') result.sort((a, b) => a.price - b.price);
    if (sortBy === 'price-high') result.sort((a, b) => b.price - a.price);
    if (sortBy === 'rating') result.sort((a, b) => b.rating - a.rating);

    return result;
  }, [products, activeCategory, searchQuery, sortBy, priceRange]);

  return (
    <div className="pt-32 pb-24 max-w-[95rem] mx-auto px-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-end gap-10 mb-20">
        <div>
          <SectionHeading title="Sanctuary Collection" subtitle="Elegance Refined" />
          <p className="text-latte-600 font-light max-w-lg text-lg">Curated essentials for the modern architectural life. mEach piece is selected for its sensory impact and longevity.</p>
        </div>
        
        <div className="flex flex-col sm:flex-row gap-6 w-full md:w-auto">
          <div className="relative group min-w-[300px]">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 text-latte-400 group-focus-within:text-stone-900 transition-colors" size={20} />
            <input 
              type="text" 
              placeholder="Search our heritage..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="bg-latte-100/50 border-none rounded-full pl-14 pr-8 py-5 text-sm focus:outline-none focus:ring-2 focus:ring-latte-200 transition-all w-full"
            />
          </div>
          <div className="relative">
            <select 
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value as any)}
              className="appearance-none bg-latte-100/50 border-none rounded-full pl-8 pr-14 py-5 text-sm focus:outline-none focus:ring-2 focus:ring-latte-200 transition-all w-full sm:w-auto cursor-pointer font-medium"
            >
              <option value="rating">Top Rated</option>
              <option value="price-low">Price: Ascending</option>
              <option value="price-high">Price: Descending</option>
            </select>
            <ChevronDown className="absolute right-5 top-1/2 -translate-y-1/2 text-latte-500 pointer-events-none" size={18} />
          </div>
        </div>
      </div>

      <div className="flex flex-col lg:flex-row gap-20">
        {/* Sidebar Filters */}
        <aside className="w-full lg:w-80 space-y-12 shrink-0">
          <div>
            <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-stone-900 mb-8 flex items-center gap-3">
              <SlidersHorizontal size={16} /> Categories
            </h4>
            <div className="space-y-4">
              {categories.map(cat => (
                <button
                  key={cat}
                  onClick={() => setActiveCategory(cat)}
                  className={`flex justify-between items-center w-full text-left text-sm py-4 px-6 rounded-2xl transition-all ${
                    activeCategory === cat 
                      ? 'bg-stone-900 text-white font-semibold shadow-xl shadow-stone-100' 
                      : 'text-latte-600 hover:bg-latte-100'
                  }`}
                >
                  {cat}
                  {activeCategory === cat && <motion.div layoutId="dot" className="w-1.5 h-1.5 bg-latte-400 rounded-full" />}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-[10px] font-bold uppercase tracking-[0.3em] text-stone-900 mb-8">Investment Range</h4>
            <div className="px-2">
              <input 
                type="range" 
                min="50" 
                max="2000" 
                step="50"
                value={priceRange}
                onChange={(e) => setPriceRange(parseInt(e.target.value))}
                className="w-full accent-stone-900 h-1 bg-latte-200 rounded-full cursor-pointer"
              />
              <div className="flex justify-between mt-4 text-[10px] font-bold uppercase tracking-widest text-latte-400">
                <span>$50</span>
                <span className="text-stone-900">Up to ${priceRange}</span>
              </div>
            </div>
          </div>

          <div className="p-8 bg-latte-900 text-white rounded-[2.5rem] overflow-hidden relative group">
            <div className="relative z-10">
              <h5 className="font-serif text-2xl mb-4 italic">Bespoke Gifting</h5>
              <p className="text-xs text-latte-200 mb-8 leading-relaxed opacity-80">Complement your luxury items with artisan wrapping and personalized notes.</p>
              <button className="text-[10px] font-bold uppercase tracking-[0.3em] border-b border-white pb-1 group-hover:gap-4 transition-all">Discover Service</button>
            </div>
            <Sparkles className="absolute -bottom-6 -right-6 text-white/5 transition-transform group-hover:scale-125 duration-1000" size={160} />
          </div>
        </aside>

        {/* Product Grid */}
        <div className="flex-1">
          <div className="flex justify-between items-center mb-12">
            <p className="text-xs font-bold uppercase tracking-[0.2em] text-latte-400">
              Showing <span className="text-stone-900">{filteredProducts.length}</span> of {products.length} sanctuary objects
            </p>
          </div>
          
          {filteredProducts.length > 0 ? (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-12">
              <AnimatePresence mode="popLayout">
                {filteredProducts.map(product => (
                  <ProductCard key={product.id} product={product} />
                ))}
              </AnimatePresence>
            </div>
          ) : (
            <motion.div 
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              className="py-48 text-center"
            >
              <FilterX size={64} className="mx-auto mb-8 text-latte-200" />
              <h3 className="text-3xl font-serif text-stone-900 mb-4">No objects match your filter</h3>
              <p className="text-latte-500 font-light mb-12">Try refining your categories or investment range.</p>
              <button 
                onClick={() => { setActiveCategory('All'); setSearchQuery(''); setPriceRange(2000); }}
                className="bg-stone-900 text-white px-12 py-5 rounded-full text-[10px] font-bold uppercase tracking-widest hover:bg-latte-900 transition-all"
              >
                Reset Sanctuary Filters
              </button>
            </motion.div>
          )}
        </div>
      </div>
    </div>
  );
};

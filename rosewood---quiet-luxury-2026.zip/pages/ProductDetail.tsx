
import React, { useState, useEffect } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
// Added Heart to the imported icons from lucide-react
import { Star, ShieldCheck, Truck, RefreshCw, ShoppingCart, Minus, Plus, ChevronLeft, Eye, Zap, Heart } from 'lucide-react';
import { useAppContext } from '../AppContext';

export const ProductDetail: React.FC = () => {
  const { selectedProductId, products, addToCart, setCurrentPage, toggleWishlist, wishlist } = useAppContext();
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState<'details' | 'shipping' | 'provenance'>('details');
  const [viewCount, setViewCount] = useState(0);

  useEffect(() => {
    setViewCount(Math.floor(Math.random() * 15) + 3);
  }, [selectedProductId]);

  const product = products.find(p => p.id === selectedProductId);
  const isWishlisted = wishlist.includes(product?.id || '');

  if (!product) return <div className="pt-48 text-center text-latte-500 font-serif italic text-2xl">Object of luxury not found.</div>;

  return (
    <div className="pt-32 pb-32 max-w-7xl mx-auto px-6">
      <button 
        onClick={() => setCurrentPage('shop')}
        className="group flex items-center gap-3 text-latte-400 hover:text-stone-900 transition-all mb-16"
      >
        <div className="w-10 h-10 rounded-full border border-latte-100 flex items-center justify-center group-hover:bg-latte-50 transition-all">
          <ChevronLeft size={18} />
        </div>
        <span className="text-[10px] font-bold uppercase tracking-[0.3em]">Back to sanctuary</span>
      </button>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-20">
        {/* Images Display */}
        <motion.div 
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-7 space-y-6"
        >
          <div className="aspect-[4/5] rounded-[3rem] overflow-hidden bg-latte-50 shadow-inner group relative">
            <img 
              src={product.images[0]} 
              alt={product.name} 
              className="w-full h-full object-cover transition-transform duration-1000 group-hover:scale-105" 
            />
            <div className="absolute top-8 left-8 flex gap-3">
              {product.isFeatured && (
                <span className="glass px-4 py-2 rounded-full text-[10px] font-bold uppercase tracking widest">Heritage Line</span>
              )}
            </div>
          </div>
          <div className="grid grid-cols-3 gap-6">
            {[1, 2, 3].map(i => (
              <div key={i} className="aspect-square rounded-2xl overflow-hidden bg-latte-50 cursor-pointer hover:ring-2 hover:ring-latte-300 transition-all">
                <img 
                  src={`https://images.unsplash.com/photo-${1600000000000 + (i * 1000)}?auto=format&fit=crop&q=80&w=400`} 
                  alt="detail" 
                  className="w-full h-full object-cover opacity-60 hover:opacity-100 transition-opacity" 
                />
              </div>
            ))}
          </div>
        </motion.div>

        {/* Narrative Side */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          className="lg:col-span-5 flex flex-col"
        >
          <div className="mb-12">
            <div className="flex items-center gap-3 text-latte-600 mb-6">
              <Zap size={14} className="text-orange-400 fill-orange-400" />
              <span className="text-[10px] font-bold uppercase tracking-[0.2em]">{viewCount} collectors viewing now</span>
            </div>
            
            <p className="text-latte-500 font-bold uppercase tracking-[0.4em] text-[10px] mb-4">{product.category}</p>
            <h1 className="text-5xl md:text-6xl font-serif text-stone-900 mb-6 tracking-tight leading-none">{product.name}</h1>
            
            <div className="flex items-center gap-6 mb-10">
              <p className="text-4xl font-light text-stone-900">${product.price}</p>
              <div className="h-6 w-[1px] bg-latte-100"></div>
              <div className="flex items-center gap-2">
                <Star size={16} fill="#D4AF37" className="text-gold-500" />
                <span className="text-xs font-bold text-stone-800">{product.rating}</span>
                <span className="text-xs text-latte-400">({product.reviewsCount} verified reviews)</span>
              </div>
            </div>

            <p className="text-latte-700 font-light leading-relaxed text-xl mb-12">
              {product.description}
            </p>
          </div>

          <div className="space-y-8 mb-16">
            <div className="flex items-center gap-6">
              <div className="flex items-center bg-latte-50 rounded-full h-20 px-4 border border-latte-100">
                <button 
                  onClick={() => setQuantity(q => Math.max(1, q - 1))}
                  className="w-12 h-12 rounded-full flex items-center justify-center text-latte-400 hover:text-stone-900 hover:bg-white transition-all"
                >
                  <Minus size={18} />
                </button>
                <span className="w-16 text-center text-xl font-serif">{quantity}</span>
                <button 
                  onClick={() => setQuantity(q => q + 1)}
                  className="w-12 h-12 rounded-full flex items-center justify-center text-latte-400 hover:text-stone-900 hover:bg-white transition-all"
                >
                  <Plus size={18} />
                </button>
              </div>
              <button 
                onClick={() => {
                  for(let i=0; i<quantity; i++) addToCart(product);
                  setCurrentPage('cart');
                }}
                className="flex-1 bg-stone-900 text-white h-20 rounded-full font-bold uppercase tracking-widest text-xs flex items-center justify-center gap-4 hover:bg-stone-800 transition-all shadow-2xl shadow-stone-100"
              >
                <ShoppingCart size={18} />
                Acquire Object
              </button>
            </div>
            
            <button 
              onClick={() => toggleWishlist(product.id)}
              className="w-full border border-latte-100 h-16 rounded-full flex items-center justify-center gap-3 text-xs font-bold uppercase tracking-widest hover:bg-latte-50 transition-all"
            >
              <Heart size={16} className={isWishlisted ? 'text-red-400 fill-red-400' : ''} />
              {isWishlisted ? 'In Sanctuary Wishlist' : 'Add to Wishlist'}
            </button>
          </div>

          {/* Benefits Grid */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 pt-16 border-t border-latte-50">
            {[
              { icon: <Truck size={22} />, title: "Concierge Delivery", desc: "Global Priority" },
              { icon: <RefreshCw size={22} />, title: "Heritage Return", desc: "30-Day Window" },
              { icon: <ShieldCheck size={22} />, title: "Secure Asset", desc: "Encrypted Auth" },
            ].map((item, i) => (
              <div key={i} className="group">
                <div className="mb-4 text-latte-400 group-hover:text-stone-900 transition-colors">{item.icon}</div>
                <h5 className="text-[10px] font-bold uppercase tracking-[0.2em] text-stone-900 mb-2">{item.title}</h5>
                <p className="text-[10px] text-latte-400 tracking-wider font-medium">{item.desc}</p>
              </div>
            ))}
          </div>

          {/* Expanded Storytelling */}
          <div className="mt-20">
            <div className="flex gap-12 border-b border-latte-50 mb-10">
              {(['details', 'shipping', 'provenance'] as const).map(tab => (
                <button
                  key={tab}
                  onClick={() => setActiveTab(tab)}
                  className={`pb-6 text-[10px] font-bold uppercase tracking-[0.3em] transition-all relative ${
                    activeTab === tab ? 'text-stone-900' : 'text-latte-400 hover:text-stone-600'
                  }`}
                >
                  {tab}
                  {activeTab === tab && (
                    <motion.div layoutId="tabLine" className="absolute bottom-0 left-0 w-full h-[1px] bg-stone-900" />
                  )}
                </button>
              ))}
            </div>
            <div className="min-h-[150px] text-latte-600 font-light text-lg leading-relaxed">
              <AnimatePresence mode="wait">
                <motion.div
                  key={activeTab}
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  exit={{ opacity: 0, y: -10 }}
                  transition={{ duration: 0.3 }}
                >
                  {activeTab === 'details' && (
                    <div className="space-y-6">
                      <p>Every architectural element of the {product.name} is designed to harmonize with the modern luxury environment. Our artisans focus on the dialogue between material and form.</p>
                      <ul className="grid grid-cols-2 gap-4 text-xs font-bold uppercase tracking-widest text-latte-500">
                        <li>• Hand-finished</li>
                        <li>• Certified Sourcing</li>
                        <li>• Non-toxic dyes</li>
                        <li>• Carbon-Neutral production</li>
                      </ul>
                    </div>
                  )}
                  {activeTab === 'shipping' && (
                    <p>We provide complimentary global concierge shipping on all heritage objects. Our standard transit time is 3-5 business days via carbon-negative logistics partners.</p>
                  )}
                  {activeTab === 'provenance' && (
                    <p>Originating from our 2026 Winter Atelier, this object represents the peak of contemporary life design. Each piece is individually numbered and accompanied by a certificate of authenticity.</p>
                  )}
                </motion.div>
              </AnimatePresence>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
};

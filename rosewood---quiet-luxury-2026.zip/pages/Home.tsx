
import React from 'react';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles, ShieldCheck, Truck, Globe } from 'lucide-react';
import { useAppContext } from '../AppContext';
import { ProductCard, SectionHeading } from '../components/UI';

export const Home: React.FC = () => {
  const { products, setCurrentPage } = useAppContext();
  const featured = products.filter(p => p.isFeatured).slice(0, 4);
  const remaining = products.filter(p => !featured.find(f => f.id === p.id)).slice(0, 8);

  return (
    <div className="pt-20 bg-latte-50">
      {/* 2026 Hero: Minimalist Architectural Design */}
      <section className="relative min-h-[95vh] flex items-center justify-center overflow-hidden">
        <div className="absolute inset-0 z-0">
          <motion.div 
            initial={{ scale: 1.1, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 2 }}
            className="w-full h-full"
          >
             <img 
               src="https://images.unsplash.com/photo-1600585152220-90363fe7e115?auto=format&fit=crop&q=80&w=1920" 
               className="w-full h-full object-cover brightness-[0.97]"
               alt="Modern Interior"
             />
          </motion.div>
          <div className="absolute inset-0 bg-white/20 backdrop-blur-[2px]"></div>
        </div>

        <div className="max-w-7xl mx-auto px-4 w-full relative z-10 text-center">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 1, delay: 0.2 }}
          >
            <span className="text-latte-800 font-bold uppercase tracking-[0.5em] text-[10px] block mb-8">Quiet Luxury Collection • 2026</span>
            <h1 className="text-7xl md:text-[10rem] font-serif text-stone-900 leading-[0.85] tracking-tighter mb-12">
              The Art of <br /> <span className="italic font-light text-latte-600">Restraint</span>
            </h1>
            <p className="text-stone-800 text-lg md:text-2xl max-w-2xl mx-auto mb-16 font-light leading-relaxed opacity-80">
              In an era of noise, we curate silence. Experience artisanal essentials crafted for the soul.
            </p>
            <div className="flex flex-col sm:flex-row items-center justify-center gap-8">
              <button 
                onClick={() => setCurrentPage('shop')}
                className="bg-stone-900 text-white px-12 py-6 rounded-full font-semibold hover:bg-latte-900 transition-all shadow-2xl flex items-center gap-4 group"
              >
                Explore Catalog
                <ArrowRight size={20} className="group-hover:translate-x-2 transition-transform" />
              </button>
              <button className="text-stone-900 font-bold uppercase tracking-[0.3em] text-xs flex items-center gap-3 border-b border-stone-900 pb-1">
                Our Story 2026
              </button>
            </div>
          </motion.div>
        </div>

        {/* Floating Accents */}
        <motion.div 
          animate={{ y: [0, -20, 0] }}
          transition={{ duration: 6, repeat: Infinity, ease: "easeInOut" }}
          className="absolute right-20 bottom-40 hidden lg:block w-48 h-64 border border-latte-300 rounded-[4rem] backdrop-blur-md"
        />
      </section>

      {/* Editorial Grid Section */}
      <section className="py-40 max-w-[90rem] mx-auto px-4">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-16 items-center">
          <div className="lg:col-span-4">
            <SectionHeading title="Timeless Objects" subtitle="Featured Selection" />
            <p className="text-latte-700 font-light text-xl leading-relaxed mb-12">
              Our 2026 philosophy revolves around the "Object of Permanence". Items designed not just to be used, but to be passed down.
            </p>
            <button 
              onClick={() => setCurrentPage('shop')}
              className="text-stone-900 font-bold uppercase tracking-widest text-xs flex items-center gap-3 group"
            >
              View All <div className="w-12 h-[1px] bg-stone-900 group-hover:w-20 transition-all"></div>
            </button>
          </div>
          <div className="lg:col-span-8 grid grid-cols-1 sm:grid-cols-2 gap-8">
            {featured.slice(0, 2).map(product => (
              <ProductCard key={product.id} product={product} />
            ))}
          </div>
        </div>
      </section>

      {/* Brand Experience: Infinite Scroll or Parallax */}
      <section className="relative h-[80vh] overflow-hidden">
        <div className="absolute inset-0 z-0">
          <img 
            src="https://images.unsplash.com/photo-1544441893-675973e31985?auto=format&fit=crop&q=80&w=1920" 
            className="w-full h-full object-cover scale-110" 
            alt="Fabric texture"
          />
          <div className="absolute inset-0 bg-latte-900/40 mix-blend-multiply"></div>
        </div>
        <div className="relative z-10 h-full flex items-center justify-center text-center text-white p-4">
          <motion.div
             initial={{ opacity: 0, scale: 0.9 }}
             whileInView={{ opacity: 1, scale: 1 }}
             viewport={{ once: true }}
             className="max-w-4xl"
          >
            <h2 className="text-5xl md:text-8xl font-serif italic mb-10">Sensory Perfection.</h2>
            <div className="grid grid-cols-2 md:grid-cols-4 gap-12 mt-20">
              {[
                { icon: <Globe />, val: "Ethical" },
                { icon: <Sparkles />, val: "Artisan" },
                { icon: <ShieldCheck />, val: "Verified" },
                { icon: <Truck />, val: "Carbon-Neg" }
              ].map((item, i) => (
                <div key={i} className="flex flex-col items-center gap-4">
                  <div className="w-16 h-16 rounded-full border border-white/30 flex items-center justify-center">{item.icon}</div>
                  <span className="text-[10px] font-bold uppercase tracking-widest">{item.val}</span>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* New Arrivals Grid */}
      <section className="py-40 max-w-7xl mx-auto px-4">
        <SectionHeading title="The Latest Drops" subtitle="2026 Curations" centered />
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-10">
          {remaining.map(product => (
             <ProductCard key={product.id} product={product} />
          ))}
        </div>
        <div className="mt-20 text-center">
          <button 
            onClick={() => setCurrentPage('shop')}
            className="px-12 py-5 border border-latte-200 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-stone-900 hover:text-white transition-all shadow-sm"
          >
            Explore Full Sanctuary
          </button>
        </div>
      </section>

      {/* Newsletter 2026 */}
      <section className="py-40 px-4 bg-cream-100 border-t border-latte-200">
        <div className="max-w-4xl mx-auto text-center">
          <SectionHeading title="Stay in Silence" subtitle="Newsletter" centered />
          <p className="text-latte-700 font-light text-lg mb-12">
            Subscribe to receive exclusive access to our 2026 Winter Drops and intimate artisan stories.
          </p>
          <div className="relative max-w-lg mx-auto">
             <input 
               type="email" 
               placeholder="Your sanctuary email"
               className="w-full bg-white border-none rounded-full py-6 px-10 text-stone-800 placeholder:text-latte-400 focus:ring-2 focus:ring-latte-300 shadow-xl transition-all"
             />
             <button className="absolute right-2 top-2 bottom-2 bg-stone-900 text-white px-8 rounded-full text-xs font-bold uppercase tracking-widest hover:bg-latte-800 transition-colors">
               Join
             </button>
          </div>
        </div>
      </section>
    </div>
  );
};

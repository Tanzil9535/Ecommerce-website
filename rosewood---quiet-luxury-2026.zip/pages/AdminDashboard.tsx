
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Plus, Search, Edit2, Trash2, Package, Users, ShoppingCart, TrendingUp, X } from 'lucide-react';
import { useAppContext } from '../AppContext';
import { Product } from '../types';

export const AdminDashboard: React.FC = () => {
  const { products, setProducts } = useAppContext();
  const [showAddModal, setShowAddModal] = useState(false);
  const [newProduct, setNewProduct] = useState<Partial<Product>>({
    name: '', price: 0, category: 'Fragrance', description: '', stock: 0
  });

  const handleDelete = (id: string) => {
    setProducts(prev => prev.filter(p => p.id !== id));
  };

  const handleAddProduct = (e: React.FormEvent) => {
    e.preventDefault();
    const product: Product = {
      ...newProduct as Product,
      id: Math.random().toString(36).substr(2, 9),
      images: ['https://picsum.photos/seed/new/800/1000'],
      rating: 5.0,
      reviewsCount: 0
    };
    setProducts(prev => [product, ...prev]);
    setShowAddModal(false);
  };

  return (
    <div className="pt-32 pb-24 max-w-7xl mx-auto px-4">
      <div className="flex justify-between items-center mb-12">
        <h1 className="text-4xl font-serif text-stone-800">Admin Dashboard</h1>
        <button 
          onClick={() => setShowAddModal(true)}
          className="bg-caramel-600 text-white px-6 py-3 rounded-xl font-bold flex items-center gap-2 hover:bg-caramel-700 transition-all"
        >
          <Plus size={20} /> Add Product
        </button>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-16">
        {[
          { icon: <Package className="text-blue-500" />, label: 'Total Products', val: products.length },
          { icon: <TrendingUp className="text-green-500" />, label: 'Sales Velocity', val: '+24%' },
          { icon: <Users className="text-purple-500" />, label: 'New Users', val: '128' },
          { icon: <ShoppingCart className="text-caramel-500" />, label: 'Open Orders', val: '14' },
        ].map((stat, i) => (
          <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-stone-100 flex items-center gap-4">
            <div className="p-3 bg-stone-50 rounded-xl">{stat.icon}</div>
            <div>
              <p className="text-xs text-stone-400 font-bold uppercase tracking-widest">{stat.label}</p>
              <p className="text-2xl font-bold text-stone-800">{stat.val}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Products Table */}
      <div className="bg-white rounded-3xl shadow-sm border border-stone-100 overflow-hidden">
        <div className="p-6 border-b border-stone-100 flex justify-between items-center bg-stone-50/50">
          <h3 className="font-bold text-stone-800">Product Management</h3>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-stone-400" size={16} />
            <input 
              type="text" 
              placeholder="Filter products..."
              className="pl-10 pr-4 py-2 bg-white border border-stone-200 rounded-lg text-sm focus:outline-none focus:border-caramel-300"
            />
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="text-xs font-bold uppercase tracking-widest text-stone-400 border-b border-stone-50">
                <th className="px-6 py-4">Product</th>
                <th className="px-6 py-4">Category</th>
                <th className="px-6 py-4">Price</th>
                <th className="px-6 py-4">Stock</th>
                <th className="px-6 py-4">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-stone-50">
              {products.map(product => (
                <tr key={product.id} className="text-sm hover:bg-stone-50/50 transition-colors">
                  <td className="px-6 py-4 flex items-center gap-4">
                    <img src={product.images[0]} className="w-10 h-10 rounded-lg object-cover" alt="" />
                    <span className="font-medium text-stone-800">{product.name}</span>
                  </td>
                  <td className="px-6 py-4 text-stone-500">{product.category}</td>
                  <td className="px-6 py-4 font-bold text-stone-800">${product.price}</td>
                  <td className="px-6 py-4">
                    <span className={`px-3 py-1 rounded-full text-[10px] font-bold ${
                      product.stock > 10 ? 'bg-green-50 text-green-700' : 'bg-red-50 text-red-700'
                    }`}>
                      {product.stock} Units
                    </span>
                  </td>
                  <td className="px-6 py-4">
                    <div className="flex gap-2">
                      <button className="p-2 text-stone-400 hover:text-caramel-600 transition-colors"><Edit2 size={16} /></button>
                      <button 
                        onClick={() => handleDelete(product.id)}
                        className="p-2 text-stone-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={16} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Add Modal */}
      {showAddModal && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center p-4">
          <div className="absolute inset-0 bg-stone-900/60 backdrop-blur-sm" onClick={() => setShowAddModal(false)}></div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.9, y: 20 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            className="relative bg-white w-full max-w-xl rounded-[2.5rem] p-10 shadow-2xl"
          >
            <div className="flex justify-between items-center mb-8">
              <h2 className="text-2xl font-serif text-stone-800">Add New Product</h2>
              <button onClick={() => setShowAddModal(false)} className="text-stone-400 hover:text-stone-600"><X size={24} /></button>
            </div>
            
            <form onSubmit={handleAddProduct} className="space-y-6">
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-stone-500">Product Name</label>
                <input 
                  type="text" required 
                  className="w-full bg-stone-50 border border-stone-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-caramel-300"
                  onChange={e => setNewProduct({...newProduct, name: e.target.value})}
                />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-stone-500">Price ($)</label>
                  <input 
                    type="number" required 
                    className="w-full bg-stone-50 border border-stone-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-caramel-300"
                    onChange={e => setNewProduct({...newProduct, price: parseFloat(e.target.value)})}
                  />
                </div>
                <div className="space-y-2">
                  <label className="text-xs font-bold uppercase tracking-widest text-stone-500">Stock</label>
                  <input 
                    type="number" required 
                    className="w-full bg-stone-50 border border-stone-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-caramel-300"
                    onChange={e => setNewProduct({...newProduct, stock: parseInt(e.target.value)})}
                  />
                </div>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-stone-500">Category</label>
                <select 
                  className="w-full bg-stone-50 border border-stone-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-caramel-300"
                  onChange={e => setNewProduct({...newProduct, category: e.target.value as any})}
                >
                  <option value="Fragrance">Fragrance</option>
                  <option value="Skincare">Skincare</option>
                  <option value="Accessories">Accessories</option>
                  <option value="Home">Home</option>
                </select>
              </div>
              <div className="space-y-2">
                <label className="text-xs font-bold uppercase tracking-widest text-stone-500">Description</label>
                <textarea 
                  rows={3}
                  className="w-full bg-stone-50 border border-stone-100 rounded-xl px-4 py-3 text-sm focus:outline-none focus:border-caramel-300"
                  onChange={e => setNewProduct({...newProduct, description: e.target.value})}
                ></textarea>
              </div>
              
              <button 
                type="submit"
                className="w-full bg-caramel-600 text-white py-4 rounded-2xl font-bold hover:bg-caramel-700 transition-all shadow-xl shadow-caramel-100"
              >
                Create Product Listing
              </button>
            </form>
          </motion.div>
        </div>
      )}
    </div>
  );
};

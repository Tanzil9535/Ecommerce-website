
import React from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Trash2, Plus, Minus, ArrowRight, ShoppingBag, Gift } from 'lucide-react';
import { useAppContext } from '../AppContext';

export const Cart: React.FC = () => {
  const { cart, updateCartQuantity, removeFromCart, setCurrentPage } = useAppContext();

  const subtotal = cart.reduce((acc, item) => acc + (item.price * item.quantity), 0);
  const shipping = subtotal > 150 ? 0 : 25;
  const total = subtotal + shipping;

  if (cart.length === 0) {
    return (
      <div className="pt-48 pb-32 text-center max-w-lg mx-auto px-4">
        <div className="w-24 h-24 bg-latte-100 rounded-full flex items-center justify-center mx-auto mb-8 text-stone-300">
          <ShoppingBag size={48} />
        </div>
        <h2 className="text-3xl font-serif text-stone-800 mb-4">Your bag is empty</h2>
        <p className="text-stone-500 mb-10 font-light">It looks like you haven't added anything to your cart yet. Explore our curated selection of luxury essentials.</p>
        <button 
          onClick={() => setCurrentPage('shop')}
          className="bg-stone-900 text-white px-10 py-4 rounded-full font-bold hover:bg-stone-800 transition-all shadow-lg"
        >
          Start Shopping
        </button>
      </div>
    );
  }

  return (
    <div className="pt-32 pb-24 max-w-7xl mx-auto px-4">
      <h1 className="text-4xl font-serif text-stone-800 mb-12">Your Shopping Bag</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-16">
        {/* Cart Items */}
        <div className="lg:col-span-2 space-y-8">
          <AnimatePresence>
            {cart.map((item) => (
              <motion.div 
                key={item.id}
                layout
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, x: -100 }}
                className="flex gap-6 pb-8 border-b border-stone-100"
              >
                <div 
                  className="w-32 h-40 rounded-2xl overflow-hidden bg-stone-100 cursor-pointer"
                  onClick={() => setCurrentPage('shop')}
                >
                  <img src={item.images[0]} alt={item.name} className="w-full h-full object-cover" />
                </div>
                
                <div className="flex-1 flex flex-col justify-between">
                  <div>
                    <div className="flex justify-between items-start mb-2">
                      <h3 className="text-xl font-serif text-stone-800">{item.name}</h3>
                      <button 
                        onClick={() => removeFromCart(item.id)}
                        className="text-stone-400 hover:text-red-500 transition-colors"
                      >
                        <Trash2 size={18} />
                      </button>
                    </div>
                    <p className="text-xs text-latte-600 font-bold uppercase tracking-widest mb-4">{item.category}</p>
                    <p className="text-lg font-medium text-stone-800">${item.price}</p>
                  </div>
                  
                  <div className="flex items-center gap-4">
                    <div className="flex items-center border border-stone-200 rounded-full">
                      <button 
                        onClick={() => updateCartQuantity(item.id, -1)}
                        className="p-2 text-stone-400 hover:text-latte-600"
                      >
                        <Minus size={14} />
                      </button>
                      <span className="w-8 text-center text-sm font-medium">{item.quantity}</span>
                      <button 
                        onClick={() => updateCartQuantity(item.id, 1)}
                        className="p-2 text-stone-400 hover:text-latte-600"
                      >
                        <Plus size={14} />
                      </button>
                    </div>
                  </div>
                </div>
              </motion.div>
            ))}
          </AnimatePresence>

          <div className="bg-latte-50 p-6 rounded-2xl border border-latte-200 flex items-center gap-4">
            <Gift className="text-latte-500" />
            <div className="flex-1">
              <p className="text-sm font-bold text-stone-800">Add a gift note?</p>
              <p className="text-xs text-stone-500 font-light">Make your order extra special with a handwritten message.</p>
            </div>
            <button className="text-latte-600 text-xs font-bold uppercase tracking-widest border-b border-latte-600">Add</button>
          </div>
        </div>

        {/* Summary */}
        <div className="lg:col-span-1">
          <div className="glass p-8 rounded-[2rem] sticky top-32 shadow-xl shadow-stone-100">
            <h3 className="text-2xl font-serif text-stone-800 mb-8">Order Summary</h3>
            
            <div className="space-y-4 mb-8">
              <div className="flex justify-between text-stone-500">
                <span className="font-light">Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              <div className="flex justify-between text-stone-500">
                <span className="font-light">Estimated Shipping</span>
                <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
              </div>
              {shipping > 0 && (
                <p className="text-[10px] text-latte-600 bg-latte-50 p-2 rounded-lg text-center">
                  Add <strong>${(150 - subtotal).toFixed(2)}</strong> more for <strong>Free Shipping</strong>
                </p>
              )}
              <div className="pt-4 border-t border-stone-100 flex justify-between items-center text-xl font-bold text-stone-800">
                <span>Total</span>
                <span>${total.toFixed(2)}</span>
              </div>
            </div>
            
            <button 
              onClick={() => setCurrentPage('checkout')}
              className="w-full bg-stone-900 text-white py-5 rounded-full font-bold flex items-center justify-center gap-3 hover:bg-stone-800 transition-all shadow-xl group"
            >
              Checkout
              <ArrowRight size={20} className="group-hover:translate-x-1 transition-transform" />
            </button>
            
            <p className="mt-6 text-[10px] text-stone-400 text-center leading-relaxed font-light">
              By checking out, you agree to Rosewood's Terms of Service and Privacy Policy. All taxes are calculated at checkout.
            </p>
          </div>
        </div>
      </div>
    </div>
  );
};
